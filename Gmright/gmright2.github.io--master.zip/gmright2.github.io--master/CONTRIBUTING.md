Gmright is a big Organization and we are here working on how to design and build or deploy our repostory 
The material of gmright is special from GitHub platform because that's where we only work at when it come on 
Coding or building that it doesn't say we cannot working on others repo or organization 

Everyone in this group should be able to represent work on time to keep gmright moving forward 
This is propod where all the files should be landing at we work every day 24 hours to make sure all the test pass 

https://gmright1.github.io/gmrightkenja-/ You are else welcome to work in this repostory is where dog hug dog this mean 
When two Organization work together to make something greater in the our community this is when this repo dog hug dog strap in 

We are really happy to see you join us we don't know what we can done  without you our favorite user 
Gmright Organization 
