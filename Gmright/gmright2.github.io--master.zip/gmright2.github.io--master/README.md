

# gmright2.github.io-
 To work with gmright.io you need to 
Pass this interesting pro.


.Copy->codes 
 

    --------------
    | s-1 == a-1|
    | der </ vol|
    | x.0 =< g.0|
    | echo off  |
    | g-review  |
    | 2/c~>c-2  |
    | sub-vision|
    | cont$v    |
    -------------

Do project:
Open/web map to start using this program or one Olof 
Code pro this app will take you to different level of content 
Users who don't know coding the will be able to found this program or 
Project useful 


