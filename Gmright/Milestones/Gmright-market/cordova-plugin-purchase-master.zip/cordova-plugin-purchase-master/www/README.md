# Note for plugin developers

This folder contains minified version of the javascript file for each platform.

They are assembled and minified from files located in `src/js`.

Compilation is done using the following command:

    make build

See the `build` target in the `Makefile` for more details.
