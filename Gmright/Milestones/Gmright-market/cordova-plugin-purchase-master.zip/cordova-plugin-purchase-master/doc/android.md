This have moved:

See https://github.com/j3k0/cordova-plugin-purchase/wiki/HOWTO#setup-android-applications 
